#!/usr/bin/python

import sys
import pickle
sys.path.append("../tools/")
import matplotlib.pyplot

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data, test_classifier
from compute_fraction import computeFraction
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import accuracy_score, precision_score, recall_score


### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".
features_list = ['poi', 'total_payments', 'fraction_to_poi', \
                'total_stock_value', \
                'fraction_from_poi', \
                'other', \
                'to_messages'] # You will need to use more features

# 'loan_advances', 'long_term_incentive', 'deferral_payments',
# 'restricted_stock_deferred', 'exercised_stock_options'

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)


### Task 2: Remove outliers

#Removing the 'TOTAL' data point outlier
data_dict.pop('TOTAL', 0)
'''
data = featureFormat(data_dict, features_list, sort_keys = True)


for point in data:
    salary = point[1]
    total_payments = point[2]
    matplotlib.pyplot.scatter( salary, total_payments )

matplotlib.pyplot.xlabel("salary")
matplotlib.pyplot.ylabel("total_payments")
matplotlib.pyplot.show()
'''

### Task 3: Create new feature(s)
### Store to my_dataset for easy export below.
my_dataset = data_dict


#Creating two new features:
#'from_poi_to_this_person' and 'from_this_person_to_poi'
for name in my_dataset:

    data_point = my_dataset[name]

    #print
    from_poi_to_this_person = data_point["from_poi_to_this_person"]
    to_messages = data_point["to_messages"]
    fraction_from_poi = computeFraction( from_poi_to_this_person, to_messages )
    #print fraction_from_poi
    data_point["fraction_from_poi"] = fraction_from_poi


    from_this_person_to_poi = data_point["from_this_person_to_poi"]
    from_messages = data_point["from_messages"]
    fraction_to_poi = computeFraction( from_this_person_to_poi, from_messages )
    #print fraction_to_poi
    data_point["fraction_to_poi"] = fraction_to_poi


### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)


### Task 4: Try a variety of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html

# Provided to give you a starting point. Try a variety of classifiers.


# Trying out a GaussianNB classifier
'''
from sklearn.naive_bayes import GaussianNB
clf = GaussianNB()
'''

# Trying out a DecisionTreeClassifier

from sklearn import tree
clf = tree.DecisionTreeClassifier(random_state=42, \
                                  criterion='entropy', \
                                  min_samples_split=4, \
                                  max_depth=4, \
                                  class_weight={0:1, 1:15})


# Pipeline
'''
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA

pca = PCA(n_components=4)
pipe = Pipeline([('pca', pca), ('dt', clf)])
print pipe
'''

# GridSearchCV
'''
from sklearn.model_selection import GridSearchCV
parameters = {'criterion':('gini', 'entropy'), \
              'min_samples_split':[2, 4, 6, 8, 10], \
              'max_depth':[2, 4, 6, 8, 10], \
              'class_weight':[{0:1, 1:5}, {0:1, 1:10}, {0:1, 1:15}]}
dt = tree.DecisionTreeClassifier(random_state=42)
clf = GridSearchCV(dt, parameters)
'''

### Task 5: Tune your classifier to achieve better than .3 precision and recall
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info:
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html

# Example starting point. Try investigating other evaluation techniques!
'''
from sklearn.cross_validation import train_test_split
features_train, features_test, labels_train, labels_test = \
    train_test_split(features, labels, test_size=0.3, random_state=42)
'''

# Here we're trying the k-fold cross cross_validation
'''
kf = KFold(n_splits=5, shuffle = True, random_state=42)
for train_indices, test_indices in kf.split(features):
    features_train = [features[ii] for ii in train_indices]
    features_test = [features[ii] for ii in test_indices]
    labels_train = [labels[ii] for ii in train_indices]
    labels_test = [labels[ii] for ii in test_indices]

    clf.fit(features_train, labels_train)
    pred = clf.predict(features_test)
    print("The accuracy score:", accuracy_score(labels_test, pred))
'''

# Here we're trying the StratifiedKFold cross_validation

print
skf = StratifiedKFold(n_splits=6, shuffle=True, random_state=42)
skf.get_n_splits(features, labels)
for train_indices, test_indices in skf.split(features, labels):
    features_train = [features[ii] for ii in train_indices]
    features_test = [features[ii] for ii in test_indices]
    labels_train = [labels[ii] for ii in train_indices]
    labels_test = [labels[ii] for ii in test_indices]

    clf.fit(features_train, labels_train)
    pred = clf.predict(features_test)
    print("The accuracy score:", accuracy_score(labels_test, pred))


# For naive_bayes and DecisionTreeClassifier

clf = clf.fit(features_train, labels_train)
pred = clf.predict(features_test)


# Implementing Pipeline
'''
pipe.fit(features_train, labels_train)
pred = pipe.predict(features_test)
'''

# Evaluation scores

print(precision_score(labels_test, pred))
print(recall_score(labels_test, pred))

print
print(accuracy_score(pred, labels_test))

#print clf.best_params_
test_classifier(clf, my_dataset, features_list)
print clf.feature_importances_


### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)
